#!/bin/bash
menu_option_one () {
  echo "Increase Traffic on BookInfo."
  /home/ibmuser/demo/cside/uc1/sim_demo_load_events.sh 1>/dev/null 2>&1
  /home/ibmuser/demo/cside/uc1/sim_demo_load.sh & 1>/dev/null 2>&1
}

menu_option_two() {
  echo "Stop ratings Microservice."
  /home/ibmuser/demo/cside/uc2/sim_demo_servicedown_events.sh >/dev/null 2>&1
  /home/ibmuser/demo/cside/uc2/sim_demo_service_down.sh >/dev/null 2>&1
}

menu_option_three() {
  echo "Metric Anomaly detection"
  /home/ibmuser/demo/cside/uc3/metric_anomaly.sh >/dev/null 2>&1
}
menu_option_four() {
  echo "NW Switch down impacting video streaming Service."
  /home/ibmuser/demo/cside/uc4/sim_videostreaming.sh >/dev/null 2>&1
}
menu_option_five() {
  echo "Biiling Service Memory Utilization"
  /home/ibmuser/demo/cside/uc5/sim_billing.sh >/dev/null 2>&1

}
menu_option_six() {
  echo "Power Failure Scope Based Grouping"
  /home/ibmuser/demo/cside/uc6/sim_power_failure.sh >/dev/null 2>&1

}
menu_option_seven() {
  echo "Power Supply Test  - Seasonal Events"
  /home/ibmuser/demo/cside/uc7/sim_generator.sh >/dev/null 2>&1
}
menu_option_eight() {
  echo "Cleaning up data from AI Manager and Event Manager"
  /home/ibmuser/demo/cside/uc8/aimanager_cleanup.sh > /dev/null 2>&1
  /home/ibmuser/demo/cside/uc8/eventmanager_cleanup.sh > /dev/null 2>&1
}



press_enter() {
  echo ""
  echo -n "	Press Enter to continue "
  read
  clear
}

incorrect_selection() {
  echo "Incorrect selection! Try again."
}

until [ "$selection" = "0" ]; do
  clear
  echo ""
  echo "    	1  -  Press 1 [AIManager] Increase load on BookInfo App"
  echo "    	2  -  Press 2 [AIManager] Stop ratings microservice in BookInfo App"
  echo "        3  -  Press 3 [MetricsManager] Check Metric Anomaly in BookInfo App performance Metrics(approx 10 mins)"
  echo "        4  -  Press 4 [TopologyManager] NW Switch down impacting VideoStreaming service"
  echo "        5  -  Press 5 [EventAnalytics] High cpu utilization for Billing App"
  echo "        6  -  Press 6 [EventAnalytics] Power failure - Scope based grouping"
  echo "        7  -  Press 7 [EventAnalytics] Power supply test - Seasonality "
  echo "" 
  echo "        8  -  Reset all faults (approx 10 mins)"
  echo "    	0  -  Exit"
  echo ""
  echo -n "  Enter selection: "
  read selection
  echo ""
  case $selection in
    1 ) clear ; menu_option_one ; press_enter ;;
    2 ) clear ; menu_option_two ; press_enter ;;
    3 ) clear ; menu_option_three ; press_enter ;;
    4 ) clear ; menu_option_four ; press_enter ;;
    5 ) clear ; menu_option_five ; press_enter ;;
    6 ) clear ; menu_option_six ; press_enter ;;
    7 ) clear ; menu_option_seven ; press_enter ;;
    8 ) clear ; menu_option_eight ; press_enter ;;
    0 ) clear ; exit ;;
    * ) clear ; incorrect_selection ; press_enter ;;
  esac
done
