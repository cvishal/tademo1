#!/bin/sh

ssh root@dns.ibmdte.net << EOF

/root/CSIDE_DATA/demo/cside/uc8/cleanup.sh

EOF

