#!/bin/sh

ssh root@10.0.0.4 << EOF

/home/ibmadmin/demo2020/demo_cside/uc6/scope_events_now.sh

EOF
