#!/bin/sh

ssh scadmin@10.0.0.4 << EOF

/home/scadmin/replay_data_bookinfo.sh


EOF


