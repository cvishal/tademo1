#!/bin/bash

curl -X POST -v -u root:P07o27xqWj8pzD7 -H "Accept: application/json" -H "Content-Type: application/json" -d @/home/ibmuser/demo/cside/uc2/ratings_down.json http://objserve-http-client-external-port-forward.apps.demo.ibmdte.net:32502/objectserver/restapi/alerts/status;
curl -X POST -v -u root:P07o27xqWj8pzD7 -H "Accept: application/json" -H "Content-Type: application/json" -d @/home/ibmuser/demo/cside/uc2/reviews-v2_down.json http://objserve-http-client-external-port-forward.apps.demo.ibmdte.net:32502/objectserver/restapi/alerts/status;
curl -X POST -v -u root:P07o27xqWj8pzD7 -H "Accept: application/json" -H "Content-Type: application/json" -d @/home/ibmuser/demo/cside/uc2/reviews-v3_down.json http://objserve-http-client-external-port-forward.apps.demo.ibmdte.net:32502/objectserver/restapi/alerts/status;
curl -X POST -v -u root:P07o27xqWj8pzD7 -H "Accept: application/json" -H "Content-Type: application/json" -d @/home/ibmuser/demo/cside/uc2/productpage_down.json http://objserve-http-client-external-port-forward.apps.demo.ibmdte.net:32502/objectserver/restapi/alerts/status;
