#!/bin/sh

ssh root@dns.ibmdte.net << EOF

oc login -u kubeadmin -p LxkXX-KUUWj-AM6Cs-ydIZz --insecure-skip-tls-verify=true https://api-int.demo.ibmdte.net:6443

oc scale --replicas=0  deployment ratings-v1 -n default

EOF
