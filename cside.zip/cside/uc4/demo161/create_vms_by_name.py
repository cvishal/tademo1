#!/usr/bin/env python
import sys
import os
import requests
import json
import time

def getToken():
    url= os.environ['OS_AUTH_URL']+'/auth/tokens?nocatalog'
    headers = {'Content-Type': 'application/json'}
    payload ={ "auth": { "identity": { "methods": ["password"],"password": {"user": {"domain": {"name": os.environ['OS_USER_DOMAIN_NAME']},"name": os.environ['OS_USERNAME'], "password": os.environ['OS_PASSWORD']} } }, "scope": { "project": { "domain": { "name": os.environ['OS_PROJECT_DOMAIN_NAME']}, "name":  os.environ['OS_PROJECT_NAME']} } }}
    retry = 3
    print "Project" + os.environ['OS_PROJECT_NAME']
    while retry > 0:
        r = requests.post(url, headers=headers, json=payload)
        if r.status_code == 201:
            print "Successfully obtained the authentication token"
            return r.headers['X-Subject-Token']
        else:
            retry = retry-1
            time.sleep(3)
    print "Failed to authenticate with devstack server, ensure that the services are running correctly"


def getFlavorId(token,flavorName):
    url = os.environ['OS_COMPUTE_API'] + "/" + os.environ['OS_PROJECT_ID'] + "/flavors"
    print url
    headers = {"X-Auth-Token": token}
    retry = 3
    ids = []
    while (retry > 0):
        r = requests.get(url, headers=headers)
        if(r.status_code == 200):
            print "Successfully obtained flavour details"
            flavors = json.loads(r.text)['flavors']
            for flavor in flavors:
                if flavor['name'] == flavorName:
                    return flavor['id']
            print "Flavour ID does not exit"
            return "null"    
        else:
            retry=retry-1
            time.sleep(3)
    
    print "Failed to obtain the flavors on the devstack instance"


def getImageId(token,imageName):
    url = os.environ['OS_COMPUTE_API'] + "/" + os.environ['OS_PROJECT_ID'] + "/images"
    headers = {"X-Auth-Token": token}
    retry = 3
    ids = []
    while (retry > 0):
        r = requests.get(url, headers=headers)
        if(r.status_code == 200):
            print "Successfully obtained image details"
            images = json.loads(r.text)['images']
            for image in images:
                if image['name'] == imageName:
                    return image['id']
            
            print "Image ID does not exit"
            return "null"
        else:
            retry=retry-1
            time.sleep(3)
    
    print "Failed to obtain the images on the devstack instance"



def createMachines(flavor, image):
    token = getToken()
    flavorId = getFlavorId(token, flavor)
    imageId = getImageId(token, image)
    ids = []
    for vm in getMachineNames():
        id = create_vm(vm, token, flavorId, imageId)
        ids.append(id)
        print id
    return ids
        

def getMachineNames():
    machines = sys.argv[1:]
    return machines

def create_vm(vm,token, flavorId, imageId):
    url = os.environ['OS_COMPUTE_API'] + "/" + os.environ['OS_PROJECT_ID'] + "/servers"
    headers = {"X-Auth-Token": token}
    payload = {"server": { "name": vm, "imageRef": imageId, "flavorRef": flavorId}}
    retry = 3
    while (retry > 0):
        r = requests.post(url, headers=headers, json=payload)
        if(r.status_code == 202):
            id = json.loads(r.text)['server']['id']
            print "Successfully created vm with id: " + id
            return id
        else:
            retry=retry-1
            time.sleep(3)
    print "Failed to create machine with name: "

createMachines("m1.nano", "cirros-0.3.5-x86_64-disk")
