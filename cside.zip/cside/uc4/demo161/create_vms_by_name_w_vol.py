#!/usr/bin/env python
import sys
import os
import requests
import json
import time

def getToken():
    url= os.environ['OS_AUTH_URL']+'/auth/tokens?nocatalog'
    headers = {'Content-Type': 'application/json'}
    payload ={ "auth": { "identity": { "methods": ["password"],"password": {"user": {"domain": {"name": os.environ['OS_USER_DOMAIN_NAME']},"name": os.environ['OS_USERNAME'], "password": os.environ['OS_PASSWORD']} } }, "scope": { "project": { "domain": { "name": os.environ['OS_PROJECT_DOMAIN_NAME']}, "name":  os.environ['OS_PROJECT_NAME']} } }}
    retry = 3
    while retry > 0:
        r = requests.post(url, headers=headers, json=payload)
        if r.status_code == 201:
            print "Successfully obtained the authentication token"
            return r.headers['X-Subject-Token']
        else:
            retry = retry-1
            time.sleep(3)
    print "Failed to authenticate with devstack server, ensure that the services are running correctly"


def getFlavorId(token,flavorName):
    url = os.environ['OS_COMPUTE_API'] + "/" + os.environ['OS_PROJECT_ID'] + "/flavors"
    headers = {"X-Auth-Token": token}
    retry = 3
    ids = []
    while (retry > 0):
        r = requests.get(url, headers=headers)
        if(r.status_code == 200):
            print "Successfully obtained flavour details"
            flavors = json.loads(r.text)['flavors']
            for flavor in flavors:
                if flavor['name'] == flavorName:
                    return flavor['id']
            print "Flavour ID does not exit"
            return
        else:
            retry=retry-1
            time.sleep(3)
    
    print "Failed to obtain the flavors on the devstack instance"


def getImageId(token,imageName):
    url = os.environ['OS_COMPUTE_API'] + "/" + os.environ['OS_PROJECT_ID'] + "/images"
    headers = {"X-Auth-Token": token}
    retry = 3
    ids = []
    while (retry > 0):
        r = requests.get(url, headers=headers)
        if(r.status_code == 200):
            print "Successfully obtained image details"
            images = json.loads(r.text)['images']
            for image in images:
                if image['name'] == imageName:
                    return image['id']
            print "image ID does not exit"
            return 
        else:
            retry=retry-1
            time.sleep(3)
    
    print "Failed to obtain the images on the devstack instance"



def createMachines(flavor, image):
    token = getToken()
    flavorId = getFlavorId(token, flavor)
    imageId = getImageId(token, image)
    ids = []
    for vm in getMachineNames():
        volId = createVolume(token,imageId)
        vmId = create_vm(vm, token, flavorId, imageId)
        ids.append(vmId)
        time.sleep(10)
        attach_volume_to_vm(token, vmId, volId)
    return ids
        

def getMachineNames():
    machines = sys.argv[1:]
    return machines


def createVolume(token, imageId):
    url = os.environ['OS_BLOCK_STORAGE'] + "/" + os.environ['OS_PROJECT_ID'] + "/volumes"
    headers = {"X-Auth-Token": token}
    payload = {"volume": { "size": 1, "availability_zone": "nova", "multiattach ": "false","imageRef": imageId ,"volume_type": "lvmdriver-1","metadata": {}}}
    retry = 3
    while retry > 0:
        r = requests.post(url, headers=headers, json=payload)
        if(r.status_code == 202):
            id = json.loads(r.text)['volume']['id']
            print "Successfully created volume with id: " + id
            return id
        else:
            retry = retry-1
            time.sleep(3)
    print "Failed to create volume"


def create_vm(vm,token, flavorId, imageId):
    url = os.environ['OS_COMPUTE_API'] + "/" + os.environ['OS_PROJECT_ID'] + "/servers"
    headers = {"X-Auth-Token": token}
    payload = {"server": { "name": vm, "imageRef": imageId, "flavorRef": flavorId}}
    retry = 3
    while (retry > 0):
        r = requests.post(url, headers=headers, json=payload)
        if(r.status_code == 202):
            id = json.loads(r.text)['server']['id']
            print "Successfully created vm with id: " + id
            return id
        else:
            print json.loads(r.text)
            retry=retry-1
            time.sleep(3)
    print "Failed to create machine with name: " + vm


def attach_volume_to_vm(token, vm, volume):
    url = os.environ['OS_BLOCK_STORAGE'] + "/" + os.environ['OS_PROJECT_ID'] + "/volumes/"+ volume+ "/action"
    headers = {"X-Auth-Token": token}
    payload = {"os-attach": {"instance_uuid": vm,"mountpoint": "/dev/vda"}}
    retry = 3
    while (retry > 0):
        r = requests.post(url, headers=headers, json=payload)
        if(r.status_code == 202):
            print "Successfully attached volume to new vm"
            return
        else:
            print r.status_code
            retry=retry-1
            time.sleep(3)
    print "Failed to attach volume"

createMachines("m1.nano", "cirros-0.3.5-x86_64-disk")
