#!/bin/sh

curl -X POST -v -u root:P07o27xqWj8pzD7 -H "Accept: application/json" -H "Content-Type: application/json" -d @server1.json http://objserve-http-client-external-port-forward.apps.demo.ibmdte.net:32502/objectserver/restapi/alerts/status;
curl -X POST -v -u root:P07o27xqWj8pzD7 -H "Accept: application/json" -H "Content-Type: application/json" -d @devstack.json http://objserve-http-client-external-port-forward.apps.demo.ibmdte.net:32502/objectserver/restapi/alerts/status;
curl -X POST -v -u root:P07o27xqWj8pzD7 -H "Accept: application/json" -H "Content-Type: application/json" -d @vss1.json http://objserve-http-client-external-port-forward.apps.demo.ibmdte.net:32502/objectserver/restapi/alerts/status;

sleep 5

curl -X POST -v -u root:P07o27xqWj8pzD7 -H "Accept: application/json" -H "Content-Type: application/json" -d @loadBalancer.json http://objserve-http-client-external-port-forward.apps.demo.ibmdte.net:32502/objectserver/restapi/alerts/status;
curl -X POST -v -u root:P07o27xqWj8pzD7 -H "Accept: application/json" -H "Content-Type: application/json" -d @videoApp.json http://objserve-http-client-external-port-forward.apps.demo.ibmdte.net:32502/objectserver/restapi/alerts/status; 

sleep 5

curl -X POST -v -u root:P07o27xqWj8pzD7 -H "Accept: application/json" -H "Content-Type: application/json" -d @server2.json http://objserve-http-client-external-port-forward.apps.demo.ibmdte.net:32502/objectserver/restapi/alerts/status;
curl -X POST -v -u root:P07o27xqWj8pzD7 -H "Accept: application/json" -H "Content-Type: application/json" -d @server3.json http://objserve-http-client-external-port-forward.apps.demo.ibmdte.net:32502/objectserver/restapi/alerts/status;
curl -X POST -v -u root:P07o27xqWj8pzD7 -H "Accept: application/json" -H "Content-Type: application/json" -d @videoApp_2.json http://objserve-http-client-external-port-forward.apps.demo.ibmdte.net:32502/objectserver/restapi/alerts/status;

sleep 2

curl -X POST -v -u root:P07o27xqWj8pzD7 -H "Accept: application/json" -H "Content-Type: application/json" -d @vss2.json http://objserve-http-client-external-port-forward.apps.demo.ibmdte.net:32502/objectserver/restapi/alerts/status;
curl -X POST -v -u root:P07o27xqWj8pzD7 -H "Accept: application/json" -H "Content-Type: application/json" -d @vss3.json http://objserve-http-client-external-port-forward.apps.demo.ibmdte.net:32502/objectserver/restapi/alerts/status;


