#!/bin/bash
for (( ; ; ))
do
   /home/ibmadmin/demo161/server1.sh
   /home/ibmadmin/demo161/server2.sh
   /home/ibmadmin/demo161/server3.sh
    sleep 5
done
