#!/bin/bash
. ticktick.sh

function empty
{
    local var="$1"

    # Return true if:
    # 1.    var is a null string ("" as empty string)
    # 2.    a non set variable is passed
    # 3.    a declared variable or array but without a value is passed
    # 4.    an empty array is passed
    if test -z "$var"
    then
        [[ $( echo "1" ) ]]
        return

    # Return true if var is zero (0 as an integer or "0" as a string)
    elif [ "$var" == 0 2> /dev/null ]
    then
        [[ $( echo "1" ) ]]
        return

    # Return true if var is 0.0 (0 as a float)
    elif [ "$var" == 0.0 2> /dev/null ]
    then
        [[ $( echo "1" ) ]]
        return
    fi

    [[ $( echo "" ) ]]
}

# server1
DATA=`curl -k -X GET -u 'noi-topology-default-user:L5bNO9ITGZRrLkMBS9x7vjK0PA2hQ2WctL26lqqtYaE=' --header 'Accept: application/json' --header 'X-TenantID: cfd95b7e-3bc7-4006-a4a8-a73a79c71255' 'https://noi-topology.default.apps.demo161.cp.fyre.ibm.com/1.0/topology/resources?_filter=name%3Dserver1&_filter=entityTypes%3Aserver&_origin=defaultProvider&_include_global_resources=false&_include_count=false&_include_status=false'`
echo $DATA
tickParse "$DATA"
server1=``_items[0]._id``
echo "server1 = $server1"

# server2
DATA=`curl -k -X GET -u 'noi-topology-default-user:L5bNO9ITGZRrLkMBS9x7vjK0PA2hQ2WctL26lqqtYaE=' --header 'Accept: application/json' --header 'X-TenantID: cfd95b7e-3bc7-4006-a4a8-a73a79c71255' 'https://noi-topology.default.apps.demo161.cp.fyre.ibm.com/1.0/topology/resources?_filter=name%3Dserver2&_filter=entityTypes%3Dvm&_origin=defaultProvider&_include_global_resources=false&_include_count=false&_include_status=false'`
echo $DATA
tickParse "$DATA"
server2=``_items[0]._id``
echo ``_items[0]._id``
echo "server2 = $server2"

# server3
DATA=`curl -k -X GET -u 'noi-topology-default-user:L5bNO9ITGZRrLkMBS9x7vjK0PA2hQ2WctL26lqqtYaE=' --header 'Accept: application/json' --header 'X-TenantID: cfd95b7e-3bc7-4006-a4a8-a73a79c71255' 'https://noi-topology.default.apps.demo161.cp.fyre.ibm.com/1.0/topology/resources?_filter=name%3Dserver3&_filter=entityTypes%3Aserver&_origin=defaultProvider&_include_global_resources=false&_include_count=false&_include_status=false'`
tickParse "$DATA"
server3=``_items[0]._id``
echo "server3 = $server3"

# server4
unset DATA
DATA=`curl -k -X GET -u 'noi-topology-default-user:L5bNO9ITGZRrLkMBS9x7vjK0PA2hQ2WctL26lqqtYaE=' --header 'Accept: application/json' --header 'X-TenantID: cfd95b7e-3bc7-4006-a4a8-a73a79c71255' 'https://noi-topology.default.apps.demo161.cp.fyre.ibm.com/1.0/topology/resources?_filter=name%3Dserver4&_filter=entityTypes%3Aserver&_origin=defaultProvider&_include_global_resources=false&_include_count=false&_include_status=false'`
tickParse "$DATA"
server4=``_items[0]._id``
echo "server4 = $server4"

# server5
unset DATA
DATA=`curl -k -X GET -u 'noi-topology-default-user:L5bNO9ITGZRrLkMBS9x7vjK0PA2hQ2WctL26lqqtYaE=' --header 'Accept: application/json' --header 'X-TenantID: cfd95b7e-3bc7-4006-a4a8-a73a79c71255' 'https://noi-topology.default.apps.demo161.cp.fyre.ibm.com/1.0/topology/resources?_filter=name%3Dserver5&_filter=entityTypes%3Aserver&_origin=defaultProvider&_include_global_resources=false&_include_count=false&_include_status=false'`
tickParse "$DATA"
server5=``_items[0]._id``
echo "server5 = $server5"

# WebLogic1
unset DATA
DATA=`curl -k -X GET -u 'noi-topology-default-user:L5bNO9ITGZRrLkMBS9x7vjK0PA2hQ2WctL26lqqtYaE=' --header 'Accept: application/json' --header 'X-TenantID: cfd95b7e-3bc7-4006-a4a8-a73a79c71255' 'https://noi-topology.default.apps.demo161.cp.fyre.ibm.com/1.0/topology/resources?_filter=uniqueId%3DWebLogic1&_origin=defaultProvider&_include_global_resources=false&_include_count=false&_include_status=false'`
tickParse "$DATA"
webLogic1=``_items[0]._id``
echo "webLogic1 = $webLogic1"

# WebLogic2
unset DATA
DATA=`curl -k -X GET -u 'noi-topology-default-user:L5bNO9ITGZRrLkMBS9x7vjK0PA2hQ2WctL26lqqtYaE=' --header 'Accept: application/json' --header 'X-TenantID: cfd95b7e-3bc7-4006-a4a8-a73a79c71255' 'https://noi-topology.default.apps.demo161.cp.fyre.ibm.com/1.0/topology/resources?_filter=uniqueId%3DWebLogic2&_origin=defaultProvider&_include_global_resources=false&_include_count=false&_include_status=false'`
tickParse "$DATA"
webLogic2=``_items[0]._id``
echo "webLogic2 = $webLogic2"

# WebLogic3
unset DATA
DATA=`curl -k -X GET -u 'noi-topology-default-user:L5bNO9ITGZRrLkMBS9x7vjK0PA2hQ2WctL26lqqtYaE=' --header 'Accept: application/json' --header 'X-TenantID: cfd95b7e-3bc7-4006-a4a8-a73a79c71255' 'https://noi-topology.default.apps.demo161.cp.fyre.ibm.com/1.0/topology/resources?_filter=uniqueId%3DWebLogic3&_origin=defaultProvider&_include_global_resources=false&_include_count=false&_include_status=false'`
tickParse "$DATA"
webLogic3=``_items[0]._id``
echo "webLogic3 = $webLogic3"

# WAS1
unset DATA
DATA=`curl -k -X GET -u 'noi-topology-default-user:L5bNO9ITGZRrLkMBS9x7vjK0PA2hQ2WctL26lqqtYaE=' --header 'Accept: application/json' --header 'X-TenantID: cfd95b7e-3bc7-4006-a4a8-a73a79c71255' 'https://noi-topology.default.apps.demo161.cp.fyre.ibm.com/1.0/topology/resources?_filter=uniqueId%3DWAS1&_origin=defaultProvider&_include_global_resources=false&_include_count=false&_include_status=false'`
tickParse "$DATA"
was1=``_items[0]._id``
echo "was1 = $was1"

# IBMBPM1
unset DATA
DATA=`curl -k -X GET -u 'noi-topology-default-user:L5bNO9ITGZRrLkMBS9x7vjK0PA2hQ2WctL26lqqtYaE=' --header 'Accept: application/json' --header 'X-TenantID: cfd95b7e-3bc7-4006-a4a8-a73a79c71255' 'https://noi-topology.default.apps.demo161.cp.fyre.ibm.com/1.0/topology/resources?_filter=uniqueId%3DIBMBPM1&_origin=defaultProvider&_include_global_resources=false&_include_count=false&_include_status=false'`
tickParse "$DATA"
bpm1=``_items[0]._id``
echo "bpm1 = $bpm1"

if empty "${server1}"
    then
        echo "server1 does not exit"
    else
body=$(cat  << EOF
{
    "_id":  "$server1"
    }
EOF
)
    curl -k -X PUT -u 'noi-topology-default-user:L5bNO9ITGZRrLkMBS9x7vjK0PA2hQ2WctL26lqqtYaE=' --header 'Content-Type: application/json' --header 'Accept: application/json' --header 'X-TenantID: cfd95b7e-3bc7-4006-a4a8-a73a79c71255' -d "$body" "https://noi-topology.default.apps.demo161.cp.fyre.ibm.com/1.0/topology/resources/${webLogic1}/references/out/runsOn"
fi
   

if empty "${server2}"
    then
        echo "server2 does not exit"
    else
body=$(cat  << EOF
{
    "_id":  "$server2"
    }
EOF
)
    curl -k -X PUT -u 'noi-topology-default-user:L5bNO9ITGZRrLkMBS9x7vjK0PA2hQ2WctL26lqqtYaE=' --header 'Content-Type: application/json' --header 'Accept: application/json' --header 'X-TenantID: cfd95b7e-3bc7-4006-a4a8-a73a79c71255' -d "$body" "https://noi-topology.default.apps.demo161.cp.fyre.ibm.com/1.0/topology/resources/${webLogic2}/references/out/runsOn"
fi

if empty "${server3}"
    then
        echo "server3 does not exit"
    else
body=$(cat  << EOF
{
    "_id":  "$server3"
    }
EOF
)
    curl -k -X PUT -u 'noi-topology-default-user:L5bNO9ITGZRrLkMBS9x7vjK0PA2hQ2WctL26lqqtYaE=' --header 'Content-Type: application/json' --header 'Accept: application/json' --header 'X-TenantID: cfd95b7e-3bc7-4006-a4a8-a73a79c71255' -d "$body" "https://noi-topology.default.apps.demo161.cp.fyre.ibm.com/1.0/topology/resources/$webLogic3/references/out/runsOn"
fi

if empty "${server4}"
    then
        echo "server4 does not exit"
    else
body=$(cat  << EOF
{
    "_id":  "$server4"
    }
EOF
)
    curl -k -X PUT -u 'noi-topology-default-user:L5bNO9ITGZRrLkMBS9x7vjK0PA2hQ2WctL26lqqtYaE=' --header 'Content-Type: application/json' --header 'Accept: application/json' --header 'X-TenantID: cfd95b7e-3bc7-4006-a4a8-a73a79c71255' -d "$body" "https://noi-topology.default.apps.demo161.cp.fyre.ibm.com/1.0/topology/resources/$was1/references/out/runsOn"
fi

if empty "${server5}"
    then
        echo "server5 does not exit"
    else
body=$(cat  << EOF
{
    "_id":  "$server5"
    }
EOF
)
    curl -k -X PUT -u 'noi-topology-default-user:L5bNO9ITGZRrLkMBS9x7vjK0PA2hQ2WctL26lqqtYaE=' --header 'Content-Type: application/json' --header 'Accept: application/json' --header 'X-TenantID: cfd95b7e-3bc7-4006-a4a8-a73a79c71255' -d "$body" "https://noi-topology.default.apps.demo161.cp.fyre.ibm.com/1.0/topology/resources/$bpm1/references/out/runsOn"
fi
