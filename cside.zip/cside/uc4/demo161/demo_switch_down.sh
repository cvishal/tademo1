#!/bin/bash

cd /home/ibmadmin/demo161

/home/ibmadmin/demo161/switch_problem.sh

