#!/bin/bash

# For this script to work you will need to have the user tagged as an admin set 
# If you do not have one set you can do it like this:
# rabbitmqctl add_user {username} {password}
# rabbitmqctl set_user_tags {username} administrator
# rabbitmqctl set_permissions -p / {username} ".*" ".*" ".*" 
# To run the script pass the {username} and {password} as 3rd and 4th arguments

if [[ $# != 4 ]]; then
echo "The RabbitMQ server's IP address or hostname, port, user and password need to be set."
echo "Example: ./create_rabbitmq_queues.sh localhost 15672 user passwd"
exit 1
fi

wget http://$1:$2/cli/rabbitmqadmin >/dev/null 2>&1

if [[ $? != 0 ]]; then
echo "The RabbitMQ Management Plugin (rabbitmqadmin) was not found, it can be enabled by running:- "
echo "> rabbitmq-plugins enable rabbitmq_management"
exit 2
fi

chmod +x rabbitmqadmin

# Create the IBM ASM Queues; these will later bind to topics...
./rabbitmqadmin declare queue --host=$1 --port=$2 --vhost="/" name="com.ibm.asm.obs.nova.notify.info" durable=false -u $3 -p $4
./rabbitmqadmin declare queue --host=$1 --port=$2 --vhost="/" name="com.ibm.asm.obs.neutron.notify.info" durable=false -u $3 -p $4
./rabbitmqadmin declare queue --host=$1 --port=$2 --vhost="/" name="com.ibm.asm.obs.cinder.notify.info" durable=false -u $3 -p $4
./rabbitmqadmin declare queue --host=$1 --port=$2 --vhost="/" name="com.ibm.asm.obs.heat.notify.info" durable=false -u $3 -p $4

# Bind Exchanges to Queues
./rabbitmqadmin declare binding --host=$1 --port=$2 --vhost="/" source="nova" destination_type="queue" destination="com.ibm.asm.obs.nova.notify.info" routing_key="notifications.info" -u $3 -p $4
./rabbitmqadmin declare binding --host=$1 --port=$2 --vhost="/" source="neutron" destination_type="queue" destination="com.ibm.asm.obs.neutron.notify.info" routing_key="notifications.info" -u $3 -p $4
./rabbitmqadmin declare binding --host=$1 --port=$2 --vhost="/" source="cinder" destination_type="queue" destination="com.ibm.asm.obs.cinder.notify.info" routing_key="notifications.info" -u $3 -p $4
./rabbitmqadmin declare binding --host=$1 --port=$2 --vhost="/" source="heat" destination_type="queue" destination="com.ibm.asm.obs.heat.notify.info" routing_key="notifications.info" -u $3 -p $4
rm rabbitmqadmin 
