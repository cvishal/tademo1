#!/bin/bash

source asm_demo-openrc.sh
python ./create_vms_by_name.py "$@"

