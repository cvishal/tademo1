#!/bin/bash

cd /home/ibmadmin/demo161

curl -X POST -v -u root:P07o27xqWj8pzD7 -H "Accept: application/json" -H "Content-Type: application/json" -d @devstack_01.json http://objserve-http-client-external-port-forward.apps.demo.ibmdte.net:32502/objectserver/restapi/alerts/status;

/home/ibmadmin/demo161/delete_vms.sh "server1"

/home/ibmadmin/demo161/delete_resource.sh "VideoStreamingApp1"

sleep 5

/home/ibmadmin/demo161/problem.sh

