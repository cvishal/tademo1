#!/bin/bash

cd /home/ibmadmin/demo161

/home/ibmadmin/demo161/create_vms.sh "server1"

curl -k -X POST -u 'noi-topology-default-user:L5bNO9ITGZRrLkMBS9x7vjK0PA2hQ2WctL26lqqtYaE=' --header 'Content-Type: application/json' --header 'Accept: application/json' --header 'X-TenantID: cfd95b7e-3bc7-4006-a4a8-a73a79c71255' -d '{"uniqueId":"VideoStreamingApp1", "role":"Front-End", "entityTypes":["process"], "matchTokens":["VideoStreamingApp1"], "name":"VideoStreamingApp1"}' 'https://noi-topology.default.apps.demo161.cp.fyre.ibm.com/1.0/topology/resources';

sleep 2

/home/ibmadmin/demo161/reconnect.sh "VideoStreamingApp1"

sleep 10

/home/ibmadmin/demo161/resolution.sh

