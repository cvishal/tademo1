#!/bin/bash

cd /home/ibmadmin/demo161

/home/ibmadmin/demo161/cleanup_devstack.sh

#start add merge rules
curl -k -v -X POST -u 'noi-topology-default-user:L5bNO9ITGZRrLkMBS9x7vjK0PA2hQ2WctL26lqqtYaE=' --header 'Content-Type: application/json' --header 'Accept: application/json' --header 'X-TenantID: cfd95b7e-3bc7-4006-a4a8-a73a79c71255' -d '{
    "name": "mergeRuleServerByName",
    "ruleType": "mergeRule",
    "tokens": ["name"],
    "ruleStatus": "enabled",
    "entityTypes": [ "server" ],
    "observers": [ "openstack-observer", "file-observer"],
    "providers": [ "*"]
}
' https://noi-topology.default.apps.demo161.cp.fyre.ibm.com/1.0/merge/rules;

curl -k -v -X POST -u 'noi-topology-default-user:L5bNO9ITGZRrLkMBS9x7vjK0PA2hQ2WctL26lqqtYaE=' --header 'Content-Type: application/json' --header 'Accept: application/json' --header 'X-TenantID: cfd95b7e-3bc7-4006-a4a8-a73a79c71255' -d '{
  "name": "mergeRuleServerUsingName",
  "ruleType": "matchTokensRule",
  "entityTypes": [ "server" ],
  "tokens": [ "name" ],
  "ruleStatus": "enabled",
  "observers": [ "openstack-observer", "file-observer"],
  "providers": [ "*" ]
}
' https://noi-topology.default.apps.demo161.cp.fyre.ibm.com/1.0/merge/rules
#end add merge rules

curl -k -v -X POST -u 'noi-topology-default-user:L5bNO9ITGZRrLkMBS9x7vjK0PA2hQ2WctL26lqqtYaE=' --header 'Content-Type: application/json' --header 'Accept: application/json' --header 'X-TenantID: cfd95b7e-3bc7-4006-a4a8-a73a79c71255' -d '{"unique_id": "VideoStreamingService", "type": "load", "parameters": {"file": "videoStreamingTopology.txt"}}' https://noi-topology.default.apps.demo161.cp.fyre.ibm.com/1.0/file-observer/jobs;

nohup /home/ibmadmin/demo161/loop_nfv.sh > /dev/null 2>&1 &

sleep 5

/home/ibmadmin/demo161/create_vms.sh "server1" "server2" "server3"
