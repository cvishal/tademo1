#!/bin/bash

source asm_demo-openrc.sh
python ./delete_vms_by_name.py "$@"

