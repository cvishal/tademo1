#!/bin/bash
. ticktick.sh

function empty
{
    local var="$1"

    # Return true if:
    # 1.    var is a null string ("" as empty string)
    # 2.    a non set variable is passed
    # 3.    a declared variable or array but without a value is passed
    # 4.    an empty array is passed
    if test -z "$var"
    then
        [[ $( echo "1" ) ]]
        return

    # Return true if var is zero (0 as an integer or "0" as a string)
    elif [ "$var" == 0 2> /dev/null ]
    then
        [[ $( echo "1" ) ]]
        return

    # Return true if var is 0.0 (0 as a float)
    elif [ "$var" == 0.0 2> /dev/null ]
    then
        [[ $( echo "1" ) ]]
        return
    fi

    [[ $( echo "" ) ]]
}

# VideoStreamingService3
unset DATA
DATA=`curl -k -X GET -u 'noi-topology-default-user:L5bNO9ITGZRrLkMBS9x7vjK0PA2hQ2WctL26lqqtYaE=' --header 'Accept: application/json' --header 'X-TenantID: cfd95b7e-3bc7-4006-a4a8-a73a79c71255' "https://noi-topology.default.apps.demo161.cp.fyre.ibm.com/1.0/topology/resources?_filter=uniqueId%3D${1}&_origin=defaultProvider&_include_global_resources=false&_include_count=false&_include_status=false"`
tickParse "$DATA"
resource_id=``_items[0]._id``
echo "$1 = $resource_id"


if empty "${resource_id}"
    then
        echo "$1 does not exit"
    else
    curl -k -X DELETE -u 'noi-topology-default-user:L5bNO9ITGZRrLkMBS9x7vjK0PA2hQ2WctL26lqqtYaE=' --header 'Accept: application/json' --header 'X-TenantID: cfd95b7e-3bc7-4006-a4a8-a73a79c71255' "https://noi-topology.default.apps.demo161.cp.fyre.ibm.com/1.0/topology/resources/${resource_id}"
    echo "$1 deleted "
fi
