source asm_demo-openrc.sh

openstack server remove volume $1 "vol_$1"

openstack server delete --wait $1

openstack volumne delete "vol_$1"

