#!/usr/bin/env python
import sys
import os
import time
import json
import requests


def getToken():
    url= os.environ['OS_AUTH_URL']+'/auth/tokens?nocatalog'
    headers = {'Content-Type': 'application/json'}
    payload ={ "auth": { "identity": { "methods": ["password"],"password": {"user": {"domain": {"name": os.environ['OS_USER_DOMAIN_NAME']},"name": os.environ['OS_USERNAME'], "password": os.environ['OS_PASSWORD']} } }, "scope": { "project": { "domain": { "name": os.environ['OS_PROJECT_DOMAIN_NAME']}, "name":  os.environ['OS_PROJECT_NAME']} } }}
    retry = 3
    while retry > 0:
        r = requests.post(url, headers=headers, json=payload)
        if r.status_code == 201:
            print "Successfully obtained the authentication token"
            return r.headers['X-Subject-Token']
        else:
            retry = retry-1
            time.sleep(3)
    print "Failed to authenticate with devstack server, ensure that the services are running correctly"

def getMachineNames():
    machines = sys.argv[1:]
    return machines

def getAllMachines(token):
    url = os.environ['OS_COMPUTE_API'] + "/" + os.environ['OS_PROJECT_ID'] + "/servers"
    headers = {"X-Auth-Token": token}
    retry = 3
    dict = {}
    while (retry > 0):
        r = requests.get(url, headers=headers)
        if(r.status_code == 200):
            print "Successfully obtained machine details"
            servers = json.loads(r.text)['servers']
            for server in servers:
               dict[server['name']]=server['id']
            return dict
        else:
            retry=retry-1
            time.sleep(3)
    
    print "Failed to obtain the servers on the devstack instance"

def deleteMachines():
    token = getToken()
    servers = getAllMachines(token)
    for vm in getMachineNames():
        delete_vm(vm, token, servers[vm])


def delete_vm(vm,token,id):
    url = os.environ['OS_COMPUTE_API'] + "/" + os.environ['OS_PROJECT_ID'] + "/servers/"+id
    headers = {"X-Auth-Token": token}
    retry = 3
    while (retry > 0):
        r = requests.delete(url, headers=headers)
        if(r.status_code == 204):
            print "Successfully deleted the machine with name: " + vm
            return
        else:
            retry=retry-1
            time.sleep(3)
    print "Failed to delete machine with name: " + vm + " please remove manually !"

deleteMachines()
