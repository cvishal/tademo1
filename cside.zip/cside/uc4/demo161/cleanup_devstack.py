#!/usr/bin/env python
import sys
import os
import requests
import time
import json

def getToken():
    url= os.environ['OS_AUTH_URL']+'/auth/tokens?nocatalog'
    headers = {'Content-Type': 'application/json'}
    payload ={ "auth": { "identity": { "methods": ["password"],"password": {"user": {"domain": {"name": os.environ['OS_USER_DOMAIN_NAME']},"name": os.environ['OS_USERNAME'], "password": os.environ['OS_PASSWORD']} } }, "scope": { "project": { "domain": { "name": os.environ['OS_PROJECT_DOMAIN_NAME']}, "name":  os.environ['OS_PROJECT_NAME']} } }}
    retry = 3
    while retry > 0:
        r = requests.post(url, headers=headers, json=payload)
        if r.status_code == 201:
            print "Successfully obtained the authentication token"
            return r.headers['X-Subject-Token']
        else:
            retry = retry-1
            time.sleep(3)
    print "Failed to authenticate with devstack server, ensure that the services are running correctly"


def deleteMachinesAndVolumes():
    token = getToken()
    for vm in getAllMachineIds(token):
        delete_vm(vm, token)
    for vol in getAllVolumeIds(token):
        delete_vol(vol, token)

def getAllMachineIds(token):
    url = os.environ['OS_COMPUTE_API'] + "/" + os.environ['OS_PROJECT_ID'] + "/servers"
    headers = {"X-Auth-Token": token}
    retry = 3
    ids = []
    while (retry > 0):
        r = requests.get(url, headers=headers)
        if(r.status_code == 200):
            print "Successfully obtained machine details"
            servers = json.loads(r.text)['servers']
            for server in servers:
                ids.append(server['id'])
            return ids
        else:
            retry=retry-1
            time.sleep(3)
    
    print "Failed to obtain the servers on the devstack instance"

def delete_vm(vm,token):
    url = os.environ['OS_COMPUTE_API'] + "/" + os.environ['OS_PROJECT_ID'] + "/servers/"+vm
    headers = {"X-Auth-Token": token}
    retry = 3
    while (retry > 0):
        r = requests.delete(url, headers=headers)
        if(r.status_code == 204):
            print "Successfully deleted the machine with id: " + vm
            return
        else:
            retry=retry-1
            time.sleep(3)
    print "Failed to delete machine with name: " + vm + " please remove manually !"

def getAllVolumeIds(token):
    url = os.environ['OS_BLOCK_STORAGE'] + "/" + os.environ['OS_PROJECT_ID'] + "/volumes"
    headers = {"X-Auth-Token": token}
    retry = 3
    ids = []
    while (retry > 0):
        r = requests.get(url, headers=headers)
        if(r.status_code == 200):
            print "Successfully obtained volume details"
            volumes = json.loads(r.text)['volumes']
            for volume in volumes:
                ids.append(volume['id'])
            return ids
        else:
            retry=retry-1
            time.sleep(3)
    
    print "Failed to obtain the servers on the devstack instance"

def delete_vol(vol,token):
    url = os.environ['OS_BLOCK_STORAGE'] + "/" + os.environ['OS_PROJECT_ID'] + "/volumes/"+vol
    headers = {"X-Auth-Token": token}
    retry = 3
    while (retry > 0):
        r = requests.delete(url, headers=headers)
        if(r.status_code == 202):
            print "Successfully deleted the volume with id: " + vol
            return
        else:
            retry=retry-1
            time.sleep(3)
    print "Failed to delete volume with name: " + vol + " please remove manually !"

deleteMachinesAndVolumes()
