#!/bin/bash

curl -X POST -v -u root:P07o27xqWj8pzD7 -H "Accept: application/json" -H "Content-Type: application/json" -d @server1_resolution.json http://objserve-http-client-external-port-forward.apps.demo.ibmdte.net:32502/objectserver/restapi/alerts/status;
curl -X POST -v -u root:P07o27xqWj8pzD7 -H "Accept: application/json" -H "Content-Type: application/json" -d @devstack_resolution.json http://objserve-http-client-external-port-forward.apps.demo.ibmdte.net:32502/objectserver/restapi/alerts/status;
curl -X POST -v -u root:P07o27xqWj8pzD7 -H "Accept: application/json" -H "Content-Type: application/json" -d @vss1_resolution.json http://objserve-http-client-external-port-forward.apps.demo.ibmdte.net:32502/objectserver/restapi/alerts/status;

sleep 5

curl -X POST -v -u root:P07o27xqWj8pzD7 -H "Accept: application/json" -H "Content-Type: application/json" -d @loadBalancer_resolution.json http://objserve-http-client-external-port-forward.apps.demo.ibmdte.net:32502/objectserver/restapi/alerts/status;
curl -X POST -v -u root:P07o27xqWj8pzD7 -H "Accept: application/json" -H "Content-Type: application/json" -d @videoApp_resolution.json http://objserve-http-client-external-port-forward.apps.demo.ibmdte.net:32502/objectserver/restapi/alerts/status;

sleep 5

curl -X POST -v -u root:P07o27xqWj8pzD7 -H "Accept: application/json" -H "Content-Type: application/json" -d @vss2_resolution.json http://objserve-http-client-external-port-forward.apps.demo.ibmdte.net:32502/objectserver/restapi/alerts/status;
curl -X POST -v -u root:P07o27xqWj8pzD7 -H "Accept: application/json" -H "Content-Type: application/json" -d @vss3_resolution.json http://objserve-http-client-external-port-forward.apps.demo.ibmdte.net:32502/objectserver/restapi/alerts/status;
curl -X POST -v -u root:P07o27xqWj8pzD7 -H "Accept: application/json" -H "Content-Type: application/json" -d @videoApp_2_resolution.json http://objserve-http-client-external-port-forward.apps.demo.ibmdte.net:32502/objectserver/restapi/alerts/status; 

sleep 5

curl -X POST -v -u root:P07o27xqWj8pzD7 -H "Accept: application/json" -H "Content-Type: application/json" -d @server2_resolution.json http://objserve-http-client-external-port-forward.apps.demo.ibmdte.net:32502/objectserver/restapi/alerts/status;
curl -X POST -v -u root:P07o27xqWj8pzD7 -H "Accept: application/json" -H "Content-Type: application/json" -d @server3_resolution.json http://objserve-http-client-external-port-forward.apps.demo.ibmdte.net:32502/objectserver/restapi/alerts/status;
curl -X POST -v -u root:P07o27xqWj8pzD7 -H "Accept: application/json" -H "Content-Type: application/json" -d @devstack_01_resolution.json http://objserve-http-client-external-port-forward.apps.demo.ibmdte.net:32502/objectserver/restapi/alerts/status;
