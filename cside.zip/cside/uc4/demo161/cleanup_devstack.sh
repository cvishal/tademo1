#!/bin/bash

source asm_demo-openrc.sh

echo "Cleaning of VMs related to demo in progress..."

echo "Cleaning of server1"
./deleteVM.sh server1 > /dev/null 2>&1

echo "Cleaning of server2"
./deleteVM.sh server2 > /dev/null 2>&1

echo "Cleaning of server3"
./deleteVM.sh server3 > /dev/null 2>&1

echo "Cleaning completed"
