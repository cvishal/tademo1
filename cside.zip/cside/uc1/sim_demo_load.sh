#!/bin/bash

while  : 
do
	echo `/usr/bin/curl -s "http://10.0.0.125:31004/productpage" | /usr/bin/grep -o "<title>.*</title>" `
	echo `/opt/go/hey-master/hey -c 1000 -n 1000 http://10.0.0.125:31004/productpage `
sleep 1
done

