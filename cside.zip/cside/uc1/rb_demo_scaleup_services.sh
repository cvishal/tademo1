#!/bin/sh
ssh root@dns.ibmdte.net << EOF
oc login -u kubeadmin -p LxkXX-KUUWj-AM6Cs-ydIZz --insecure-skip-tls-verify=true https://api-int.demo.ibmdte.net:6443

oc scale --replicas=2  deployment details-v1 -n default

EOF

curl -X POST -v -u root:P07o27xqWj8pzD7 -H "Accept: application/json" -H "Content-Type: application/json" -d @/home/ibmuser/demo/cside/uc1/details_clear.json http://objserve-http-client-external-port-forward.apps.demo.ibmdte.net:32502/objectserver/restapi/alerts/status;

curl -X POST -v -u root:P07o27xqWj8pzD7 -H "Accept: application/json" -H "Content-Type: application/json" -d @/home/ibmuser/demo/cside/uc1/productpage_clear.json http://objserve-http-client-external-port-forward.apps.demo.ibmdte.net:32502/objectserver/restapi/alerts/status;

curl -X POST -v -u root:P07o27xqWj8pzD7 -H "Accept: application/json" -H "Content-Type: application/json" -d @/home/ibmuser/demo/cside/uc1/reviews-v1_clear.json http://objserve-http-client-external-port-forward.apps.demo.ibmdte.net:32502/objectserver/restapi/alerts/status;

curl -X POST -v -u root:P07o27xqWj8pzD7 -H "Accept: application/json" -H "Content-Type: application/json" -d @/home/ibmuser/demo/cside/uc1/reviews-v2_clear.json http://objserve-http-client-external-port-forward.apps.demo.ibmdte.net:32502/objectserver/restapi/alerts/status;

curl -X POST -v -u root:P07o27xqWj8pzD7 -H "Accept: application/json" -H "Content-Type: application/json" -d @/home/ibmuser/demo/cside/uc1/reviews-v3_clear.json http://objserve-http-client-external-port-forward.apps.demo.ibmdte.net:32502/objectserver/restapi/alerts/status;

curl -X POST -v -u root:P07o27xqWj8pzD7 -H "Accept: application/json" -H "Content-Type: application/json" -d @/home/ibmuser/demo/cside/uc1/ratings_clear.json http://objserve-http-client-external-port-forward.apps.demo.ibmdte.net:32502/objectserver/restapi/alerts/status;
