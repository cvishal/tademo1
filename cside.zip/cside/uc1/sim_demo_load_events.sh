#!/bin/sh

curl -X POST -v -u root:P07o27xqWj8pzD7 -H "Accept: application/json" -H "Content-Type: application/json" -d @/home/ibmuser/demo/cside/uc1/details.json http://objserve-http-client-external-port-forward.apps.demo.ibmdte.net:32502/objectserver/restapi/alerts/status;

curl -X POST -v -u root:P07o27xqWj8pzD7 -H "Accept: application/json" -H "Content-Type: application/json" -d @/home/ibmuser/demo/cside/uc1/productpage.json http://objserve-http-client-external-port-forward.apps.demo.ibmdte.net:32502/objectserver/restapi/alerts/status;

curl -X POST -v -u root:P07o27xqWj8pzD7 -H "Accept: application/json" -H "Content-Type: application/json" -d @/home/ibmuser/demo/cside/uc1/reviews-v1.json http://objserve-http-client-external-port-forward.apps.demo.ibmdte.net:32502/objectserver/restapi/alerts/status;

curl -X POST -v -u root:P07o27xqWj8pzD7 -H "Accept: application/json" -H "Content-Type: application/json" -d @/home/ibmuser/demo/cside/uc1/reviews-v2.json http://objserve-http-client-external-port-forward.apps.demo.ibmdte.net:32502/objectserver/restapi/alerts/status;

curl -X POST -v -u root:P07o27xqWj8pzD7 -H "Accept: application/json" -H "Content-Type: application/json" -d @/home/ibmuser/demo/cside/uc1/reviews-v3.json http://objserve-http-client-external-port-forward.apps.demo.ibmdte.net:32502/objectserver/restapi/alerts/status;

curl -X POST -v -u root:P07o27xqWj8pzD7 -H "Accept: application/json" -H "Content-Type: application/json" -d @/home/ibmuser/demo/cside/uc1/ratings.json http://objserve-http-client-external-port-forward.apps.demo.ibmdte.net:32502/objectserver/restapi/alerts/status;

