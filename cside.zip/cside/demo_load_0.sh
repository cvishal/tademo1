#!/bin/bash


while  : 
do
	echo `/usr/bin/curl -s "http://10.0.0.125:31004/productpage" | /usr/bin/grep -o "<title>.*</title>" `
sleep 1
done

